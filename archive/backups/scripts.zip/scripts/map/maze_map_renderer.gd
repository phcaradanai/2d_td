extends Node2D
class_name MazeMapRenderer

## Lightweight maze-TD map renderer
## Draws grid, spawn/core markers, and optional guideline overlay.
## No per-frame processing — redraws on demand only.

# ------------------------------------------------------------------ colors
const BG_COLOR        := Color(0.06, 0.07, 0.10, 1.0)
const GRID_COLOR      := Color(0.12, 0.14, 0.18, 0.35)
const SPAWN_COLOR     := Color(0.3,  0.9,  0.4,  0.9)
const CORE_COLOR      := Color(0.9,  0.25, 0.15, 0.9)
const GUIDELINE_COLOR := Color(0.25, 0.35, 0.5,  0.18)

# ------------------------------------------------------------------ state
var _grid_origin: Vector2 = Vector2.ZERO
var _grid_size:   float   = 64.0
var _grid_cols:   int     = 10
var _grid_rows:   int     = 10

var _spawn_cells:     Array[Vector2i] = []
var _base_cells:      Array[Vector2i] = []
var _guideline_cells: Array[Vector2i] = []
var _draw_guideline:  bool = false


# ================================================================== setup
func _ready() -> void:
	set_process(false)


func setup(p_level_manager: Node) -> void:
	# --- read grid parameters from the level manager -------------------
	_grid_origin = _read_vec2_attr(p_level_manager, "grid_origin", Vector2.ZERO)
	_grid_size   = _read_float_attr(p_level_manager, "grid_size", 64.0)
	_grid_cols   = _read_int_attr(p_level_manager, "grid_cols", 10)
	_grid_rows   = _read_int_attr(p_level_manager, "grid_rows", 10)

	# --- spawn / base / guideline from level_data ----------------------
	var ldl: Variant = p_level_manager.get("level_data")
	if ldl != null and ldl is Dictionary:
		var ld: Dictionary = ldl as Dictionary
		_spawn_cells     = _extract_cells(ld.get("spawn_cells", []))
		_base_cells      = _extract_cells(ld.get("base_cells", []))
		_guideline_cells = _extract_cells(ld.get("guideline_cells", []))

	# --- fallback: single spawn / base cell ---------------------------
	if _spawn_cells.is_empty():
		_spawn_cells = _extract_single_cell(p_level_manager, "spawn_cell")

	if _base_cells.is_empty():
		_base_cells = _extract_single_cell(p_level_manager, "base_cell")

	# --- fallback guideline from multi_paths.default -------------------
	if _guideline_cells.is_empty():
		var mp: Variant = p_level_manager.get("multi_paths")
		if mp != null and mp is Dictionary:
			_guideline_cells = _extract_cells((mp as Dictionary).get("default", []))

	_draw_guideline = not _guideline_cells.is_empty()

	queue_redraw()


# =============================================================== helpers
func _read_vec2_attr(obj: Node, attr: String, default: Vector2) -> Vector2:
	var v: Variant = obj.get(attr)
	if v == null:
		return default
	if v is Vector2:
		return v as Vector2
	if v is Array and (v as Array).size() >= 2:
		var a: Array = v as Array
		return Vector2(float(a[0]), float(a[1]))
	return default


func _read_float_attr(obj: Node, attr: String, default: float) -> float:
	var v: Variant = obj.get(attr)
	if v == null:
		return default
	return float(v)


func _read_int_attr(obj: Node, attr: String, default: int) -> int:
	var v: Variant = obj.get(attr)
	if v == null:
		return default
	return int(v)


func _extract_single_cell(obj: Node, attr: String) -> Array[Vector2i]:
	var v: Variant = obj.get(attr)
	if v == null:
		return []
	if v is Vector2i:
		return [v as Vector2i]
	if v is Array and (v as Array).size() >= 2:
		var a: Array = v as Array
		return [Vector2i(int(a[0]), int(a[1]))]
	return []


## Handles both Array[Vector2i] and Array[Array] (nested [x,y] arrays).
func _extract_cells(cells) -> Array[Vector2i]:
	var result: Array[Vector2i] = []
	if cells == null:
		return result

	if not (cells is Array):
		return result

	for cell in (cells as Array):
		if cell is Vector2i:
			result.append(cell as Vector2i)
		elif cell is Array and (cell as Array).size() >= 2:
			var a: Array = cell as Array
			result.append(Vector2i(int(a[0]), int(a[1])))

	return result


# =================================================================== draw
func _draw() -> void:
	_draw_background()
	_draw_grid()
	_draw_spawn_cells()
	_draw_base_cells()
	if _draw_guideline:
		_draw_guideline_path()


func _draw_background() -> void:
	var tw: float = float(_grid_cols) * _grid_size
	var th: float = float(_grid_rows) * _grid_size
	draw_rect(Rect2(_grid_origin, Vector2(tw, th)), BG_COLOR)


func _draw_grid() -> void:
	var tw: float = float(_grid_cols) * _grid_size
	var th: float = float(_grid_rows) * _grid_size

	# vertical lines
	for col in range(_grid_cols + 1):
		var x: float = _grid_origin.x + float(col) * _grid_size
		draw_line(Vector2(x, _grid_origin.y), Vector2(x, _grid_origin.y + th), GRID_COLOR, 1.0)

	# horizontal lines
	for row in range(_grid_rows + 1):
		var y: float = _grid_origin.y + float(row) * _grid_size
		draw_line(Vector2(_grid_origin.x, y), Vector2(_grid_origin.x + tw, y), GRID_COLOR, 1.0)


func _cell_center(ci: Vector2i) -> Vector2:
	return _grid_origin + Vector2(
		float(ci.x) * _grid_size + _grid_size * 0.5,
		float(ci.y) * _grid_size + _grid_size * 0.5
	)


func _draw_spawn_cells() -> void:
	var font: Font = ThemeDB.fallback_font
	var font_size: int = maxi(int(_grid_size * 0.18), 8)
	var half: float = _grid_size * 0.32
	var label_offset: float = half + font_size * 0.6

	for cell in _spawn_cells:
		var center: Vector2 = _cell_center(cell) + Vector2(0.0, -_grid_size * 0.08)

		# upward-pointing triangle
		var pts := PackedVector2Array([
			center + Vector2(0.0, -half),
			center + Vector2(-half * 0.866, half * 0.5),
			center + Vector2( half * 0.866, half * 0.5),
		])
		draw_colored_polygon(pts, SPAWN_COLOR)

		# "SPAWN" label below triangle
		var label_rect := Rect2(
			center.x - _grid_size * 0.5,
			center.y + label_offset,
			_grid_size,
			float(font_size)
		)
		draw_string(font, label_rect.position + Vector2(0, float(font_size)),
			"SPAWN", HORIZONTAL_ALIGNMENT_CENTER, label_rect.size.x, font_size, SPAWN_COLOR)


func _draw_base_cells() -> void:
	var font: Font = ThemeDB.fallback_font
	var font_size: int = maxi(int(_grid_size * 0.18), 8)
	var half: float = _grid_size * 0.32
	var label_offset: float = half + font_size * 0.6

	for cell in _base_cells:
		var center: Vector2 = _cell_center(cell) + Vector2(0.0, -_grid_size * 0.08)

		# diamond (rotated square)
		var pts := PackedVector2Array([
			center + Vector2(0.0, -half),
			center + Vector2( half, 0.0),
			center + Vector2(0.0,  half),
			center + Vector2(-half, 0.0),
		])
		draw_colored_polygon(pts, CORE_COLOR)

		# "CORE" label below diamond
		var label_rect := Rect2(
			center.x - _grid_size * 0.5,
			center.y + label_offset,
			_grid_size,
			float(font_size)
		)
		draw_string(font, label_rect.position + Vector2(0, float(font_size)),
			"CORE", HORIZONTAL_ALIGNMENT_CENTER, label_rect.size.x, font_size, CORE_COLOR)


func _draw_guideline_path() -> void:
	if _guideline_cells.is_empty():
		return

	const ARROW_EVERY := 10  # place an arrow roughly every N cells along the path
	var path_size: int = _guideline_cells.size()

	for i in range(path_size - 1):
		var from_pos: Vector2 = _cell_center(_guideline_cells[i])
		var to_pos:   Vector2 = _cell_center(_guideline_cells[i + 1])

		# dashed segment
		draw_dashed_line(from_pos, to_pos, GUIDELINE_COLOR, 1.0, _grid_size * 0.15, true)

		# small arrow head at this intermediate point if it's an arrow cell
		if _guideline_cells[i].x % ARROW_EVERY == 0 and _guideline_cells[i].y % ARROW_EVERY == 0:
			var dir: Vector2 = from_pos.direction_to(to_pos)
			_draw_small_arrow(to_pos, dir, _grid_size * 0.12)

	# always draw arrow at the final cell
	if path_size >= 2:
		var last_idx: int = path_size - 1
		var last_pos: Vector2 = _cell_center(_guideline_cells[last_idx])
		var prev_pos: Vector2 = _cell_center(_guideline_cells[last_idx - 1])
		var dir: Vector2 = prev_pos.direction_to(last_pos)
		_draw_small_arrow(last_pos, dir, _grid_size * 0.18)


func _draw_small_arrow(at: Vector2, dir: Vector2, size: float) -> void:
	if dir.length_squared() < 0.0001:
		return

	var perp: Vector2 = Vector2(-dir.y, dir.x)
	var base:  Vector2 = at - dir * size * 0.5
	var tip:   Vector2 = at + dir * size * 0.5

	var wing: float = size * 0.45
	var left:  Vector2 = tip - dir * wing + perp * wing * 0.6
	var right: Vector2 = tip - dir * wing - perp * wing * 0.6

	# arrow body (short stem)
	draw_line(base, tip, GUIDELINE_COLOR, 1.0)
	# arrow head
	draw_line(tip, left,  GUIDELINE_COLOR, 1.0)
	draw_line(tip, right, GUIDELINE_COLOR, 1.0)
